package com.example.myapplicationnnnn;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.YuvImage;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import lib.Bluetooth.BluetoothDeviceListActivity;
import lib.ORB.ORB;

import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.concurrent.ExecutionException;

public class mainActivity extends AppCompatActivity {

    private static final String TAG = "Test";
    private TextView txt;
    private ORB orb;
    private static final String AG = "ColorDetection";
    private ImageView imageView;
    private Bitmap currentBitmap;
    private final int BLUETOOTH_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt = findViewById(R.id.Txt_1);

        // Define and set the message handler for robot messages
        Handler msgHandler = new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case ORB.CONNECTION_STATE_CHANGED:
                        // Handle the connection state change
                        showConnectionMsg();
                        break;
                    case ORB.DATA_RECEIVED:
                        // Handle the data received from the robot
                        showDataMsg(msg);
                        break;
                    default:
                        super.handleMessage(msg);
                }
            }};

        // Initialize ORB and configure motors
        orb = new ORB();
        orb.init(this, msgHandler);
        orb.configMotor(0, 144, 50, 50, 30);
        orb.configMotor(3, 144, 50, 50, 30);

        // Pass the message handler to the ORB object
        orb.setMessageHandler(msgHandler);

        // Setup directional movement buttons
        Button btnForward = findViewById(R.id.forward_btn);
        Button btnBackward = findViewById(R.id.backward_btn);
        Button btnLeft = findViewById(R.id.left_btn);
        Button btnRight = findViewById(R.id.right_btn);
        Button btnStop = findViewById(R.id.stop_btn);
//pending
        // Set touch listeners for movement buttons
        btnForward.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        moveForward();
                        break;
                    case MotionEvent.ACTION_UP:
                        stopMovement();
                        break;
                }
                return true;
            }
        });

        btnBackward.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        moveBackward();
                        break;
                    case MotionEvent.ACTION_UP:
                        stopMovement();
                        break;
                }
                return true;
            }
        });

        btnLeft.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        turnLeft();
                        break;
                    case MotionEvent.ACTION_UP:
                        stopMovement();
                        break;
                }
                return true;
            }
        });

        btnRight.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        turnRight();
                        break;
                    case MotionEvent.ACTION_UP:
                        stopMovement();
                        break;
                }
                return true;
            }
        });

        /*btnForward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveForward();
            }
        });

        btnBackward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveBackward();
            }
        });

        btnLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                turnLeft();
            }
        });

        btnRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                turnRight();
            }
        });
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopMovement();
            }
        });
*/
        // Set up button listeners
        Button btn_4 = findViewById(R.id.Btn_4);
        btn_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(mainActivity.this, "toast is beginning", Toast.LENGTH_LONG).show();
            }
        });

        Button btn_2 = findViewById(R.id.Btn_2);
        btn_2.setOnClickListener(new myOnClickListener());

        Button btn_3 = findViewById(R.id.Btn_3);
        btn_3.setOnTouchListener(new myOnTouchListener());

        // Button to start Bluetooth device selection
        Button btn_bluetooth = findViewById(R.id.bluetooth_01);
        btn_bluetooth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onButtonClick();
            }
        });

        // Button to control the motors
        Button btn_motor = findViewById(R.id.bluetooth_02);
        btn_motor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                controlMotors();
            }
        });

        // Initialize the capture button
        Button captureButton = findViewById(R.id.image_capture_button);
        captureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                takePhoto();
            }
        });

        // CameraX provider request
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture = ProcessCameraProvider.getInstance(this);
        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();
                // You can now bind the camera lifecycle to your activity
                bindCameraUseCases(cameraProvider);
                bindPreview(cameraProvider);
            } catch (ExecutionException | InterruptedException e) {
                // Handle any errors (e.g., exceptions related to obtaining the camera provider)
                e.printStackTrace();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void bindPreview(ProcessCameraProvider cameraProvider) {
        // Initialize Preview use case
        Preview preview = new Preview.Builder().build();
        PreviewView previewView = findViewById(R.id.viewFinder);  // Ensure this ID matches your layout file
        preview.setSurfaceProvider(previewView.getSurfaceProvider());

        // Initialize ImageCapture use case
        imageCapture = new ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build();

        // Initialize ImageAnalysis use case
        MyAnalyzer analyzer = new MyAnalyzer();
        ImageAnalysis imageAnalysis = new ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build();
        imageAnalysis.setAnalyzer(ContextCompat.getMainExecutor(this), analyzer);

        // Select the camera (e.g., back camera)
        CameraSelector cameraSelector = new CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                .build();

        // Bind all use cases to the camera lifecycle
        try {
            cameraProvider.unbindAll(); // Unbind previous use cases
            cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, imageCapture, imageAnalysis);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to bind camera use cases", Toast.LENGTH_SHORT).show();
        }
    }

    private void bindCameraUseCases(ProcessCameraProvider cameraProvider) {

        CameraSelector cameraSelector = new CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                .build();

        // Example code for a basic Preview use case:
        Preview preview = new Preview.Builder().build();
        preview.setSurfaceProvider(new PreviewView(this).getSurfaceProvider());

        // Image Analysis use case
        ImageAnalysis imageAnalysis = new ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build();

        // Set the analyzer
        imageAnalysis.setAnalyzer(ContextCompat.getMainExecutor(this), new MyAnalyzer());

        // Bind the lifecycle of cameras to the lifecycle owner
        cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview);
    }
    private ImageCapture imageCapture;
    private void takePhoto() {
        if (imageCapture == null) {
            Toast.makeText(this, "Camera is not ready. Please wait.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a file to save the photo
        File photoFile = new File(
                getOutputDirectory(),
                new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss-SSS", Locale.US)
                        .format(System.currentTimeMillis()) + ".jpg"
        );

        ImageCapture.OutputFileOptions outputOptions = new ImageCapture.OutputFileOptions.Builder(photoFile).build();

        imageCapture.takePicture(outputOptions, ContextCompat.getMainExecutor(this),
                new ImageCapture.OnImageSavedCallback() {
                    @Override
                    public void onImageSaved(@NonNull ImageCapture.OutputFileResults outputFileResults) {
                        String msg = "Photo saved: " + photoFile.getAbsolutePath();
                        Toast.makeText(mainActivity.this, msg, Toast.LENGTH_SHORT).show();
                        Log.d(TAG, msg);
                    }

                    @Override
                    public void onError(@NonNull ImageCaptureException exception) {
                        String errorMsg = "Photo capture failed: " + exception.getMessage();
                        Toast.makeText(mainActivity.this, errorMsg, Toast.LENGTH_SHORT).show();
                        Log.e(TAG, errorMsg);
                    }
                });
    }

    private File getOutputDirectory() {
        File mediaDir = getExternalMediaDirs()[0];
        if (mediaDir != null) {
            File dir = new File(mediaDir, "CameraXPhotos");
            if (!dir.exists() && !dir.mkdirs()) {
                Log.e(TAG, "Failed to create directory");
                return getFilesDir();
            }
            return dir;
        } else {
            Log.e(TAG, "External media directory not available");
            return getFilesDir();
        }
    }

    class MyAnalyzer implements ImageAnalysis.Analyzer {
        @Override
        public void analyze(@NonNull ImageProxy imageProxy) {
            // Convert ImageProxy to Bitmap
            Bitmap bitmap = imageProxyToBitmap(imageProxy);
            if (bitmap != null) {
                detectRedUsingHSV(bitmap); // Use the method
            }
            imageProxy.close();


            // Check a specific pixel color (center of the image)
            assert bitmap != null;
            int centerX = bitmap.getWidth() / 2;
            int centerY = bitmap.getHeight() / 2;

            try {
                int pixelColor = getPixel(bitmap, centerX, centerY);
                int red = Color.red(pixelColor);
                int green = Color.green(pixelColor);
                int blue = Color.blue(pixelColor);

                Log.d(TAG, String.format("Center Pixel Color - R: %d, G: %d, B: %d", red, green, blue));

                // Display color values on the screen (or use for further processing)
                runOnUiThread(() -> {
                    TextView colorTextView = findViewById(R.id.colorTextView); // Ensure this TextView exists in your layout
                    if (colorTextView != null) {
                        colorTextView.setText(String.format("R: %d, G: %d, B: %d", red, green, blue));
                    }
                });
            } catch (IllegalArgumentException e) {
                Log.e(TAG, "Invalid pixel coordinates: " + e.getMessage());
            }

            // Close the image proxy
            imageProxy.close();
        }

        private int getPixel(Bitmap bm, int x, int y) {
            if (bm != null && x >= 0 && y >= 0 && x < bm.getWidth() && y < bm.getHeight()) {
                return bm.getPixel(x, y);
            } else {
                throw new IllegalArgumentException("Invalid x or y coordinate");
            }
        }
    }
    // Helper method to convert ImageProxy to Bitmap
    private Bitmap imageProxyToBitmap(ImageProxy imageProxy) {
        ImageProxy.PlaneProxy[] planes = imageProxy.getPlanes();
        ByteBuffer yBuffer = planes[0].getBuffer();
        ByteBuffer uBuffer = planes[1].getBuffer();
        ByteBuffer vBuffer = planes[2].getBuffer();

        int ySize = yBuffer.remaining();
        int uSize = uBuffer.remaining();
        int vSize = vBuffer.remaining();

        byte[] nv21 = new byte[ySize + uSize + vSize];
        yBuffer.get(nv21, 0, ySize);
        vBuffer.get(nv21, ySize, vSize);
        uBuffer.get(nv21, ySize + vSize, uSize);

        YuvImage yuvImage = new YuvImage(nv21, ImageFormat.NV21, imageProxy.getWidth(), imageProxy.getHeight(), null);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        yuvImage.compressToJpeg(new Rect(0, 0, imageProxy.getWidth(), imageProxy.getHeight()), 100, out);
        byte[] jpegBytes = out.toByteArray();

        // Decode JPEG bytes into a Bitmap
        Bitmap immutableBitmap = BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.length);

        // Create a mutable copy
        return immutableBitmap.copy(Bitmap.Config.ARGB_8888, true);
    }


    public void detectRedUsingHSV(Bitmap bitmap) {
        if (bitmap == null) {
            Log.e(TAG, "Bitmap is null.");
            return;
        }

        boolean redDetected = false;
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int centerX = width / 2;
        int centerY = height / 2;

        Bitmap mutableBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true); // Create a mutable copy
        Canvas canvas = new Canvas(mutableBitmap); // Draw on this bitmap
        Paint paint = new Paint();
        paint.setColor(Color.GREEN);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2);

        int sumX = 0;
        int sumY = 0;
        int redPixelCount = 0;

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                int pixel = bitmap.getPixel(x, y);

                // Convert pixel to HSV
                float[] hsv = new float[3];
                Color.colorToHSV(pixel, hsv);

                float hue = hsv[0]; // Hue ranges from 0 to 360
                float saturation = hsv[1]; // Saturation ranges from 0 to 1
                float value = hsv[2]; // Value ranges from 0 to 1


                // Define thresholds for red color
                if (((hue >= 0 && hue <= 15) || (hue >= 345 && hue <= 360)) && saturation >= 0.5 && value >= 0.5) {
                    sumX += x;
                    sumY += y;
                    redPixelCount++;
                }
            }
        }

        if (redPixelCount > 0) {
            int redCenterX = sumX / redPixelCount;
            int redCenterY = sumY / redPixelCount;
            drawCenterCross(canvas, redCenterX, redCenterY);

            Log.d(TAG, String.format("Red object center at X: %d, Y: %d", redCenterX, redCenterY));
            controlRobotMovement(centerX, centerY, redCenterX, redCenterY);
        } else {
            Log.d(TAG, "No red object detected.");
        }

        ImageView imageView = findViewById(R.id.imageView);
        if (imageView != null) {
            imageView.setImageBitmap(mutableBitmap);
        }
    }

    private void drawCenterCross(Canvas canvas, int x, int y) {
        Paint crossPaint = new Paint();
        crossPaint.setColor(Color.GREEN);
        crossPaint.setStrokeWidth(5);
        canvas.drawLine(x - 20, y, x + 20, y, crossPaint);
        canvas.drawLine(x, y - 20, x, y + 20, crossPaint);
    }

    private void controlRobotMovement(int centerX, int centerY, int redX, int redY) {
        int deltaX = redX - centerX;
        int deltaY = redY - centerY;

        String movementCommand = "";

        if (Math.abs(deltaX) > 20) {
            if (deltaX > 0) {
                movementCommand = "MOVE RIGHT";
            } else {
                movementCommand = "MOVE LEFT";
            }
        }
        if (Math.abs(deltaY) > 20) {
            if (deltaY > 0) {
                movementCommand += " MOVE FORWARD";
            } else {
                movementCommand += " MOVE BACKWARD";
            }
        }

        if (!movementCommand.isEmpty()) {
            sendCommandToRobot(movementCommand.trim());
        } else {
            sendCommandToRobot("STOP");
        }
    }

    private void sendCommandToRobot(String command) {
        Log.d(TAG, "Command to robot: " + command);
        // Example: Send the command to the robot via Bluetooth, WiFi, etc.
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == BLUETOOTH_REQUEST_CODE) {
            orb.openBluetooth(
                    BluetoothDeviceListActivity.onActivityResult(resultCode, data)
            );
        }
    }

    // Method to display connection messages
    public void showConnectionMsg() {
        switch (orb.getConnectionState()) {
            case ORB.CONNECTION_CONNECTED:
                Toast.makeText(this, "Bluetooth connected", Toast.LENGTH_SHORT).show();
                break;
            case ORB.CONNECTION_NOT_CONNECTED:
                Toast.makeText(this, "Bluetooth NOT connected", Toast.LENGTH_LONG).show();
                break;
            case ORB.CONNECTION_WAITING:
                // No action required for waiting state
                break;
            default:
                break;
        }
    }

    // Method to display data messages
    private void showDataMsg(Message msg) {
        String data = (String) msg.obj;  // Example: get data from message
        txt.setText("Data received: " + data);
    }

    // Movement Methods for Motor Control
    public void turnLeft() {
        orb.setMotor(0, ORB.Mode.SPEED, 500, 0);
        orb.setMotor(3, ORB.Mode.SPEED, 500, 0);
        txt.setText("Turning Left");
    }

    public void turnRight() {
        orb.setMotor(0, ORB.Mode.SPEED, -500, 0);
        orb.setMotor(3, ORB.Mode.SPEED, -500, 0);
        txt.setText("Turning Right");
    }

    public void moveForward() {
        orb.setMotor(0, ORB.Mode.SPEED, -3000, 0);
        orb.setMotor(3, ORB.Mode.SPEED, 3000, 0);
        txt.setText("Moving Forward");
    }

    public void moveBackward() {
        orb.setMotor(0, ORB.Mode.SPEED, 3000, 0);
        orb.setMotor(3, ORB.Mode.SPEED, -3000, 0);
        txt.setText("Moving Backward");
    }

    public void stopMovement() {
        orb.setMotor(0, ORB.Mode.SPEED, 0, 0);
        orb.setMotor(3, ORB.Mode.SPEED, 0, 0);
        txt.setText("Stopped");
    }

    // Method to control motors
    public void controlMotors() {
        orb.setMotor(0, ORB.Mode.SPEED, 100, 0);
        orb.setMotor(3, ORB.Mode.SPEED, 100, 0);
        txt.setText("Motors 0 and 3 set to speed 100");
    }

    // Method to start Bluetooth device selection
    public void onButtonClick() {
        BluetoothDeviceListActivity.startBluetoothDeviceSelect(this, BLUETOOTH_REQUEST_CODE);
    }

    public void myOnClick(View view) {
        txt.setText("Button 1 clicked");
    }

    class myOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            txt.setText("Button 2 clicked");
        }
    }

    class myOnTouchListener implements View.OnTouchListener {
        @Override
        public boolean onTouch(View v, MotionEvent e) {
            float x = e.getX() / v.getMeasuredWidth();
            float y = e.getY() / v.getMeasuredHeight();

            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    txt.setText("Button 3 clicked X=" + String.format("%04.2f", x) + " Y=" + String.format("%04.2f", y));
                    break;
                case MotionEvent.ACTION_MOVE:
                    txt.setText("Button 3 moved   X=" + String.format("%04.2f", x) + " Y=" + String.format("%04.2f", y));
                    break;
                case MotionEvent.ACTION_UP:
                    txt.setText("Button 3 released");
                    break;
                default:
                    return false;
            }
            return true;
        }
    }
}
