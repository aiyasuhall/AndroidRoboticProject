package com.example.myapplicationnnnn;

import android.content.res.Configuration;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Timer;
import java.util.TimerTask;

import lib.ORB.ORB;

public class Activity extends AppCompatActivity
{
    private static  String TAG = "Test";
    private TextView txt;
    private ORB orb;
    private final int BLUETOOTH_REQUEST_CODE = 100;


    //-----------------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        txt = findViewById(R.id.Txt_1);

        // Add to onCreate()

        TimerTask timerTask = new TimerTask()
        {
            int cnt = 0;

            @Override
            public void run()
            {
                Log.i(TAG,"TimerTask: " + cnt);
                cnt++;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        txt.setText("TimerTask: " + cnt);
                    }
                });
            }
        };

        Timer timer = new Timer();
        timer.schedule( timerTask, 1000,1000);


        txt.setText("Time elapsed: 0 seconds");
        Log.i(TAG, "onCreate");

        orb = new ORB();
        orb.init(this, null);
        orb.configMotor(0, 144, 50, 50, 30);
        orb.configMotor(3, 144, 50, 50, 30);
    }

    //-----------------------------------------------------------------
    @Override
    protected void onStart()
    {
        super.onStart();
        Log.i(TAG, "onStart");
    }

    //-----------------------------------------------------------------
    @Override
    protected void onResume()
    {
        super.onResume();
        Log.i(TAG, "onResume");
    }

    //-----------------------------------------------------------------
    @Override
    protected void onPause()
    {
        super.onPause();
        Log.i(TAG, "onPause");
    }

    //-----------------------------------------------------------------
    @Override
    protected void onStop()
    {
        super.onStop();
        Log.i(TAG, "onStop");
    }

    //-----------------------------------------------------------------
    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        Log.i(TAG, "onDestroy");
    }

    //-----------------------------------------------------------------
    @Override
    protected void onRestart()
    {
        super.onRestart();
        Log.i(TAG, "onRestart");
    }

    //-----------------------------------------------------------------
    /*
    add to AndroidManifest.xml:
     <application
       ...
        <activity
            ...
            android:configChanges="orientation|keyboard|keyboardHidden|screenLayout|uiMode|screenSize|smallestScreenSize"
            >

    */
    @Override
    public void onConfigurationChanged(Configuration config)
    {
        super.onConfigurationChanged(config);
        Log.i(TAG, "onConfigurationChanged");
    }
}

