/**
 * Low level protocol interface
 *@author Thomas Breuer
 *
 */
package lib.ORB;